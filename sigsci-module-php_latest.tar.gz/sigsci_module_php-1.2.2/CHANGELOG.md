# PHP SDK Module Release Notes

## 1.2.2 2018-01-31

* Support multipart/form-data post
* Send all HTTP headers to agent for inspection

## 1.2.1 2017-08-23

* Fix module type

## 1.2.0 2017-03-21

* Send XML posts to agent

## 1.1.1 2016-07-20

* No operational changes
* Adds new download option https://dl.signalsciences.net/sigsci-module-php/sigsci-module-php_latest.tar.gz

## 1.1.0 2016-07-14

* Improved error handling
* Switch to SemVer version numbers

## 1.0.0.52 2016-02-16

* General simplification and improvement of networking calls
* Improved error messages
* MessagePack library upgraded
* Supports detection of open redirects
* Configuration change: Originally HTTP methods that were inspected
  where explicitly listed (whitelisted, e.g. "GET", "POST") using the
  `allowed_methods` configuration parameter. The logic is now
  inverted, and one lists methods that should be ignored (blacklisted,
  e.g. "OPTIONS", "CONNECT") using the `ignore_methods`
  parameter. This allows for the detection of invalid or malicious
  HTTP requests.
* More detailed PHP version information is sent to the agent for better
  identification and debugging.

## 1.0.0.48 2015-10-26

* Initial release
